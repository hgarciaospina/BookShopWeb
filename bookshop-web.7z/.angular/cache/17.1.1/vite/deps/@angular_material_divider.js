import {
  MatDivider,
  MatDividerModule
} from "./chunk-YMOP6IV7.js";
import "./chunk-XHD4G2AQ.js";
import "./chunk-OHWTRHKL.js";
import "./chunk-6UASFX43.js";
import "./chunk-5PDYDH2M.js";
import "./chunk-XS2YB5N4.js";
import "./chunk-L5CNU75I.js";
import "./chunk-MOVD35PJ.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
