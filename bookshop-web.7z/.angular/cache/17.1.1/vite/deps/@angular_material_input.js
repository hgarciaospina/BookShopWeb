import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-2RY2SMFU.js";
import "./chunk-SKVBBZIU.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-6KGXHPK6.js";
import "./chunk-XHD4G2AQ.js";
import "./chunk-OHWTRHKL.js";
import "./chunk-6UASFX43.js";
import "./chunk-5PDYDH2M.js";
import "./chunk-XS2YB5N4.js";
import "./chunk-L5CNU75I.js";
import "./chunk-MOVD35PJ.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
