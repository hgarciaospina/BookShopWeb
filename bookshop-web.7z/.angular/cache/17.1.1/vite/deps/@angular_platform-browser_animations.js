import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-OHWTRHKL.js";
import "./chunk-6UASFX43.js";
import "./chunk-5PDYDH2M.js";
import "./chunk-XS2YB5N4.js";
import "./chunk-L5CNU75I.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-MOVD35PJ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
